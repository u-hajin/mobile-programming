package com.example.usuynmidtest

import java.io.Serializable

class MyData(var name: String, var corp: String, var tel: String, var count: Int = 0) : Serializable
